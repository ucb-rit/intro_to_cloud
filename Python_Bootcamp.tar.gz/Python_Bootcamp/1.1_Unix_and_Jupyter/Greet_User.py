import sys

'''
Greet_User.py [Name]
Greet_User takes a name as input
Greet_User greets the user based on the given name
'''

user_name = sys.argv[1]
print 'Greetings {}!'.format(user_name)
