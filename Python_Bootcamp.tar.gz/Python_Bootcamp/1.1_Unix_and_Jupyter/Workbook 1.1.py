
# coding: utf-8

# In[1]:

print 'hello world'


# In[2]:

print "I'm excited to be learning Python this week!"

